
def stt_transcribe(wav_bytes: bytes):
    raise RuntimeError("STT disabled: install faster-whisper and wire it before use")
